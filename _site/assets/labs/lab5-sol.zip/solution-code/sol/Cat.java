package sol;

import java.io.*;

public class Cat {

    /**
     * Reads from a file using a BufferedReader and writes the contents to a
     * second file using a BufferedWriter.
     *
     * @param reader - a buffered reader for the file
     * @param writer - a buffered writer to write to
     */
    public static void cat(BufferedReader reader, BufferedWriter writer) {
        // TODO: read and write lines until EOF is reached!
        String line = "";
        try {
            while ((line = reader.readLine()) != null) {
                writer.write(line);
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("ERROR: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        if (args.length != 2) {
            System.out.println("Usage: <input file> <output file>");
            System.exit(0);
        }

        try (BufferedReader br = new BufferedReader(new FileReader(args[0]));
             BufferedWriter bw = new BufferedWriter(new FileWriter(args[1]))) {
            cat(br, bw);
        } catch (FileNotFoundException e) {
            System.out.println("ERROR: " + e.getMessage());
        } catch (IOException e) {
            System.out.println("ERROR: IOException");
        }}
}
