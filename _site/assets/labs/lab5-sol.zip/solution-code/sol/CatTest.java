package sol;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import org.junit.Assert;
import org.junit.Test;
import sol.Cat;

public class CatTest {

  @Test
  public static void testCat() {
    BufferedReader r2 = null;
    BufferedReader r3 = null;

    try (BufferedReader r1 =
            new BufferedReader(new FileReader("PATH TO SOME FILE A"));
            BufferedWriter w1 =
                    new BufferedWriter(new FileWriter(
                            "PATH TO A DIFFERENT, EMPTY FILE B"))) {

      Cat.cat(r1, w1);
      // Note: flush is called here because Cat.cat does not necessarily flush the bufferedWriter
      // unless called from main
      w1.flush();

      // set up readers for the two files
      r2 = new BufferedReader(new FileReader("SAME PATH TO FILE A"));
      r3 = new BufferedReader(new FileReader("SAME PATH TO FILE B"));

      String line1 = r2.readLine();
      String line2 = r3.readLine();

      // ensure every line is the same
      while (line1 != null && line2 != null) {
        Assert.assertEquals(line1, line2);

        line1 = r2.readLine();
        line2 = r3.readLine();
      }

      // ensure neither file had more lines than the other
      Assert.assertNull(line1);
      Assert.assertNull(line2);
    } catch (FileNotFoundException e) {
      System.out.println("DessertCase was not found!");
    } catch (IOException e) {
      System.out.println("There was an IO issue!");
    }
  }

}
