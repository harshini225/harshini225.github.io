package sol;

public class WhilePractice {
    public void posPrefix() {
        int[] theArr = {5, 6, 2, -1, 4};
        int i = 0;

        while (theArr[i] > 0) {
            System.out.println(theArr[i]);
            i++;
        }
    }

    public int numFree(int idx) {
        boolean[] seatsArray = {true, true, false, false, false, false, true, false, true};
        int count = 0;

        while(!seatsArray[idx]) {
            count++;
            idx++;
        }

        return count;
    }
}
