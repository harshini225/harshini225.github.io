package sol;
import java.io.*;
import java.nio.Buffer;

public class Doc {

    /**
     * Reads from console until EOF, then writes all lines to writer.
     *
     * @param writer - a BufferedWriter writing to a file.
     */
    public static void toDocument(BufferedWriter writer) {
        String typedLine = "";
        try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
            while ((typedLine = br.readLine()) != null) {
                writer.write(typedLine + " ");
            }

            writer.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("Usage: <output file>");
            System.exit(0);
        }

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(args[0]))) {
            toDocument(bw);
        } catch (IOException e) {
            System.out.println("ERROR: " + e.getMessage());
        }
    }

}
