package sol;

import org.junit.Assert;
import org.junit.Test;
import src.IBST;

public class BSTTest {
  
  @Test
  public void testLeaf() {
    IBST leaf = new Leaf();
    int nc = 12;
    Assert.assertFalse(leaf.contains(nc));
    Assert.assertEquals(0,leaf.treeDepth());
    leaf = leaf.insert(nc);
    Assert.assertTrue(leaf.contains(nc));
    Assert.assertEquals(1,leaf.treeDepth());
  }

  @Test
  public void testSmallTrees() {
    int twelve = 12;
    int thirteen = 13;
    int fourteen = 14;
    IBST small = new Node(thirteen, new Leaf(), new Leaf());
    Assert.assertFalse(small.contains(twelve));
    Assert.assertTrue(small.contains(thirteen));
    Assert.assertFalse(small.contains(fourteen));
    small.insert(twelve);
    small.insert(fourteen);
    Assert.assertTrue(small.contains(twelve));
    Assert.assertTrue(small.contains(thirteen));
    Assert.assertTrue(small.contains(fourteen));
    Assert.assertFalse(small.contains(15));
    Assert.assertEquals(small.treeDepth(), 2);
  }

  @Test
  public void testDepth() {
    // Test the height of the BST
    // Note, a root node has a depth of 1

    IBST root = new Node(6, new Leaf(), new Leaf());
    Assert.assertEquals(1, root.treeDepth());

    root.insert(7);
    Assert.assertEquals(2, root.treeDepth());

    root.insert(8);
    Assert.assertEquals(3, root.treeDepth());

    root.insert(9);
    Assert.assertEquals(4, root.treeDepth());

    root.insert(5);
    Assert.assertEquals(4, root.treeDepth());
  }
}
