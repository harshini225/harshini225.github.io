package sol;
import src.IBST;

import java.lang.Math;

public class Node implements IBST {

  private int value;
  private IBST left;
  private IBST right;

  /**
   * Instantiates a BST
   *
   * @param value - The value to be held in the root node.
   * @param left - The left subtree
   * @param right - The right subtree
   */
  public Node(int value, IBST left, IBST right) {
    this.value = value;
    this.left = left;
    this.right = right;
  }



  @Override
  public IBST insert(int n) {
    if (n < this.value) {
      this.left = this.left.insert(n);
    } else {
      this.right = this.right.insert(n);
    }
    return this;
  }

  @Override
  public boolean contains(int n) {
    if (this.value == n) {
      return true;
    } else if (this.value < n) {
      return this.right.contains(n);
    } else {
      return this.left.contains(n);
    }
  }

  @Override
  public int treeDepth(){

    int leftHeight = this.left.treeDepth();
    int rightHeight = this.right.treeDepth();

    return Math.max(leftHeight,rightHeight) + 1;
  }

  @Override
  public IBST getLeft() {
    return this.left;
  }

  @Override
  public IBST getRight() {
    return this.right;
  }


}
