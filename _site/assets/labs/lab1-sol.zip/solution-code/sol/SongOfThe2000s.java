package sol;

/**
 * The TwoThousandsSong class has two fields for a song's name and its listener count.
 */
public class SongOfThe2000s {

    private String name;
    private double listenerCount;

    /**
     *  Constructor for a SongOfThe2000s
     * @param name - The song's name
     * @param listenerCount - The song's listener count
     */
    public SongOfThe2000s(String name, double listenerCount) {
        this.name = name;
        this.listenerCount = listenerCount;
    }

    /**
     * Getter method for the name of a song
     * @return The name of a song
     */
    public String getName() {
        return this.name;
    }

    /**
     * Getter method for the listener count of a song
     * @return The listener count
     */
    public double getListenerCount() {
        return this.listenerCount;
    }
 }


