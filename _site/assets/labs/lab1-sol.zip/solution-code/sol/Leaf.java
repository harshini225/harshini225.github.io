package sol;

import src.IBST;

public class Leaf implements IBST {

  public Leaf() { }

  @Override
  public IBST insert(int n) {
    return new Node(n, new Leaf(), new Leaf());
  }

  @Override
  public boolean contains(int n) {
    return false;
  }

  @Override
  public int treeDepth() {
    return 0;
  }

  @Override
  public IBST getLeft() {
    return null;
  }

  @Override
  public IBST getRight() {
    return null;
  }
}
