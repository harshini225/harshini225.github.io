package src;

public interface IBST {

  /**
   * Inserts an element into the IBST.
   *
   * @param n - a Comparable to be inserted to the tree
   * @return the IBST resulting from inserting n into the current IBST
   */
  IBST insert(int n);

  /**
   * Checks whether a specific element is contained within the IBST.
   *
   * @param n - The element the user is searching for.
   * @return true if n is in the IBST, false otherwise.
   */
  boolean contains(int n);

  /**
   * Returns the depth of the IBST
   *
   * @return an int that represents the height of tree
   */
  int treeDepth();

  /**
   * Returns the left child node
   * @return Left child node
   */
  IBST getLeft();

  /**
   * Returns the right child node
   * @return Right child node
   */
  IBST getRight();

}
