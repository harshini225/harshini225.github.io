package sol;

/**
 * A class representing a meeting time
 */
public class MeetingTime {
    private DayOfWeek dayOfWeek;
    private int startTime;

    /**
     * A constructor for meeting time.
     *
     * @param dayOfWeek the day of the week
     * @param startTime the hour that the meeting starts, in 24 hour time
     */
    public MeetingTime(DayOfWeek dayOfWeek, int startTime) {
        this.dayOfWeek = dayOfWeek;
        this.startTime = startTime;
    }

    @Override
    public String toString() {
        return this.dayOfWeek + " at " + this.startTime;
    }

    /**
     * Returns the hours from this meeting time to a given one. Assumes that
     * the furthest meeting time that can be in the future is anytime on the
     * day one week from today.
     *
     * @param date the time to compute hours until
     * @return the hours until date
     */
    public int hoursUntil(MeetingTime date) {
        int today = this.dayOfWeek.ordinal();
        int otherDay = date.dayOfWeek.ordinal();
        int hoursUntil = date.getStartTime() - this.startTime;
        int daysUntil = otherDay - today;

        if (otherDay < today) {
            daysUntil +=  7;
        } else if (otherDay == today && hoursUntil < 0) {
            daysUntil = 7;
        }

        return 24 * daysUntil + hoursUntil;
    }

    public int getStartTime() {
        return this.startTime;
    }
}