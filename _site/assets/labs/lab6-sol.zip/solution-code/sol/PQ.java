package sol;

import java.util.Comparator;
import java.util.PriorityQueue;

/**
 * A class that works with priority queues.
 */
public class PQ {
    public static void printPQ(PriorityQueue queue){
        while(!queue.isEmpty()) {
            System.out.print(queue.poll() + " " );
        }
        System.out.println();
    }

    public static void main(String[] args) {
        PriorityQueue<Integer> nums = new PriorityQueue<>();
        nums.add(10);
        nums.add(20);
        nums.add(30);
        nums.add(0);
        nums.add(-14);
        nums.add(14);
        nums.add(33);
//        PQ.emptyPQ(nums);

        Comparator<CSLab> labsByCode = (lab1, lab2) -> {
            return Integer.compare(lab1.getCourseCode(), lab2.getCourseCode());
        };

        MeetingTime now = new MeetingTime(DayOfWeek.WEDNESDAY, 16);
        Comparator<CSLab> labsByTime = (lab1, lab2) -> {
            int timeUntil1 = now.hoursUntil(lab1.getMeetingTime());
            int timeUntil2 = now.hoursUntil(lab2.getMeetingTime());
            return Integer.compare(timeUntil1, timeUntil2);
        };

        PriorityQueue<CSLab> byCode = new PriorityQueue<>(labsByCode);
        PriorityQueue<CSLab> byTime = new PriorityQueue<>(labsByTime);

        for (int i = 1; i <= 5; i++) {
            DayOfWeek day = DayOfWeek.values()[(int) (Math.random() * 7)];
            CSLab lab = new CSLab(i, new MeetingTime(day, (int) (Math.random() * 24)));
            byCode.add(lab);
            byTime.add(lab);
        }

        System.out.println("Order by code: ");
        printPQ(byCode);
//        PQ.emptyPQ(byCode);
        System.out.println("Order by time:");
        printPQ(byTime);
//        PQ.emptyPQ(byTime);
    }
}
