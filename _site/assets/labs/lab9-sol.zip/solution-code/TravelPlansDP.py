class TravelPlansDP:
    def __init__(self, distance, snack_cost):
        # warning: do NOT change this method
        # the field representing the distance you can travel in one step
        self.distance = distance
        # the array storing what the cost of stopping at a single stop
        self.snack_cost = snack_cost
        # the number/index of the last store (naming for readability of later code)
        self.max_store_num = len(self.snack_cost) - 1

        # the array to store optimal costs 
        self.opt_cost = []
        # the array to store optimal paths 
        self.opt_path = []

        self.init_table()
        self.fill_table()
 
    def init_table(self):
        """initialize both opt_cost and opt_path to arrays of the right size 
        with default values"""
        for x in range(0, len(self.snack_cost)):
            self.opt_cost.append(float('-inf'))
            self.opt_path.append([])

    def fill_table(self):
        """fill in the min costs and corresponding paths at every index of each array"""
        # fill in the values for the leaf values from the tree
        for index in range(self.max_store_num - self.distance + 1, self.max_store_num + 1):
            self.opt_cost[index] = self.snack_cost[index]
            self.opt_path[index] = [index]

        # fill in the values for the remaining store numbers (from leaves to first store)
        for index in range(self.max_store_num - self.distance, -1, -1):
            # compute min cost across next stops
            min_value = float('inf')
            min_value_index = float('inf')
            # try each next allowed stop and use the smallest value
            # best_index = self.find_min_val_index(index + 1, index + self.distance)
            for next_stop in range(index + 1, index + self.distance + 1):
                compare = self.opt_cost[next_stop]
                if compare < min_value:
                    min_value = compare
                    min_value_index = next_stop
            self.opt_cost[index] = self.snack_cost[index] + min_value
            # must use + here, since append would otherwise modify the later list
            self.opt_path[index] = ([index] + self.opt_path[min_value_index])

    def optimal_cost(self):
        """return the optimal cost starting from the first index"""
        return self.opt_cost[0]

    def optimal_path(self):
        """return the optimal path starting from the first index"""
        return self.opt_path[0]


if __name__ == "__main__":
    tp1 = TravelPlansDP(2, [1, 5, 2, 2, 4, 3])
    optimal_cost = tp1.optimal_cost()
    # str in Python is like toString in Java
    print("tp1 optimal cost is " + str(tp1.optimal_cost()))
    # TODO: write more tests here!

    # these still need to be checked for correctness
    """
    test = TravelPlansDP(3, [0, 1, 2])  # 2
    print(test.optimal_cost())
    print(test.optimal_path())
    dp = TravelPlansDP(3, [0, 1, 2])  # 2
    print(dp.optimal_cost())
    print(dp.optimal_path())
    dp1 = TravelPlansDP(3, [5, 1, 3, 4, 2, 5, 2, 1, 4, 3, 2])  # 6
    print(dp1.optimal_cost())
    print(dp1.optimal_path())
    dp2 = TravelPlansDP(2, [5, 1, 3, 4, 2, 5, 2, 1, 4, 3, 2])  # 14
    print(dp2.optimal_cost())
    print(dp2.optimal_path())
    dp6 = TravelPlansDP(3, [3, 0, 2, 5, 5, 5, 6, 3, 5, 6, 7, 10, 2])  # 16
    print(dp6.optimal_cost())
    print(dp6.optimal_path())
    dp3 = TravelPlansDP(2, [3, 0, 2, 5, 5, 5, 6, 3, 5, 6, 7, 10, 2])  # 27
    print(dp3.optimal_cost())
    print(dp3.optimal_path())
    dp4 = TravelPlansDP(1, [2, 1])  # 3
    print(dp4.optimal_cost())
    print(dp4.optimal_path())
    """
