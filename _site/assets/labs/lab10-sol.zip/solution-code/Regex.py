import re


def fill_in_doc(filename):
    f = open(filename, "r")
    string = f.readline()

    doc = ""
    while string:
        doc += string
        string = f.readline()

    return doc


class Registrar:
    def __init__(self, file):
        """
        :param file: the path to the file that you should read in
        """

        self.document = fill_in_doc(file)
        self.email_regex = r"\b[a-z\-]+[\_a-z\-]*\d*@brown\.edu\b"
        # The following more "correct" regex prevents multiple dashes and underscores in a row
        # self.email_regex = r"\b(?:[a-z]+(?:\-[a-z]+)*)(?:_(?:[a-z]+(?:\-[a-z]+)*)+)*\d*@brown\.edu\b"
        self.course_regex = r"[A-Z]{3,4}[0-9]{4}[A-Z]?"

    def view_emails(self):
        """
        Prints all of the matches with the email regex
        :return: None
        """
        matches = re.findall(self.email_regex, self.document)
        print(matches)

    def view_courses(self):
        """
        prints all of the matches with the course regex
        :return: None
        """
        matches = re.findall(self.course_regex, self.document)
        print(matches)

    def make_changes(self, to_change, replacement):
        """
        :param to_change: the subsequence of self.document that should be changed
        :param replacement: the string that will replace the matched regex
        :return: None; sets the document to the change that gets made
        """
        self.document = re.sub(to_change, replacement, self.document)


if __name__ == "__main__":
    registrar = Registrar("registrations.txt")

    # Try running your code with our provided text file and see if your results
    # look reasonable!
    registrar.view_emails()
    registrar.view_courses()

    registrar.make_changes(registrar.email_regex, "###")
    registrar.view_emails()
