package lec18DFSBFS;

public class Main {
    public static void main(String [] args) {
        BusGraph neBuses = new BusGraph();

        CityVertex man = new CityVertex("Manchester");
        neBuses.addCity(man);
        CityVertex bos = new CityVertex("Boston");
        neBuses.addCity(bos);
        CityVertex pvd = new CityVertex("Providence");
        neBuses.addCity(pvd);
        CityVertex wos = new CityVertex("Worcester");
        neBuses.addCity(wos);
        CityVertex har = new CityVertex("Hartford");
        neBuses.addCity(har);

        neBuses.addRoute(man, bos);
        neBuses.addRoute(bos, pvd);
        neBuses.addRoute(bos, wos);
        neBuses.addRoute(pvd, bos);
        neBuses.addRoute(wos, har);

        System.out.println(man);
        System.out.println(bos);

        System.out.println(neBuses.canReach(bos, pvd)); // true
        System.out.println(neBuses.canReach(bos, har)); // true
        System.out.println(neBuses.canReach(har, bos)); // false
        System.out.println(neBuses.canReach(pvd, pvd)); // true
    }
}
