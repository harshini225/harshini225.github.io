package lec18DFSBFS;

import java.util.LinkedList;

public class CityVertex {
    LinkedList<CityVertex> toCities;
    String name;

    public CityVertex(String nm) {
        this.name = nm;
        this.toCities = new LinkedList<CityVertex>();
    }

    public void addEdge(CityVertex toVertex) {
        this.toCities.add(toVertex);
    }

    public boolean canReach(CityVertex dest) {
        if (this.equals(dest)) {
            return true;
        }
        for (CityVertex neighbor : this.toCities) {
            if (neighbor.canReach(dest)) {
                return true;
            }
        }
        return false;
    }

    public String toString() {
        String retstring = "City " + this.name + " goes to { ";
        for (CityVertex toCity : this.toCities) {
            retstring += toCity.name + " ";
        }
        retstring += "}";
        return retstring;
    }
}
