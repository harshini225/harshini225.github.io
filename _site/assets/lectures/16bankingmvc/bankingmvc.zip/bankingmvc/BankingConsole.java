package bankingmvc;

import java.util.Scanner;

public class BankingConsole {
    BankingService controller;

    BankingConsole(BankingService b) {
        this.controller = b;
    }

    public void loginScreen() {
        Scanner keyboard = new Scanner(System.in);
        System.out.println("Welcome to the Bank.  Please log in.");
        System.out.print("Enter your username: ");
        String username = keyboard.next();
        System.out.print("Enter your password: ");
        String password = keyboard.next();
        try {
            controller.login(username, password);
            System.out.println("Thanks for logging in!");
        } catch (CustNotFoundExn e) {
            System.out.println("No such user; please try again");
            this.loginScreen();
        }
    }
}
