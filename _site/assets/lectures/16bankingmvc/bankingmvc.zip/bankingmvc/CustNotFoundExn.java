package bankingmvc;

// Exception is the class of things that work
// with throw command
public class CustNotFoundExn extends Exception {
    String name;
    public CustNotFoundExn(String n) {
        this.name = n;
    }
}
