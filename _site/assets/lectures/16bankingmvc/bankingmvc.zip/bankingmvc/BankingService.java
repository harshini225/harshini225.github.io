package bankingmvc;
import java.util.LinkedList;

public class BankingService {
    private LinkedList<Account> accounts;
    private LinkedList<Customer> customers;

    public BankingService(){
        this.accounts = new LinkedList<Account>();
        this.customers = new LinkedList<Customer>();
    }

    public void addAccount(Account newA) {
        accounts.add(newA);
    }

    private Account findAccount(int forAcctNum) {
        for (Account acct : this.accounts) {
            if (acct.numMatches(forAcctNum)) {
                return acct;
            }
        }
        return null;
    }

    private Customer findCustomer(String name) throws CustNotFoundExn {
        for (Customer cust : this.customers) {
            if (cust.nameMatches(name)) {
                return cust;
            }
        }
        throw new CustNotFoundExn(name);
    }

    public double getBalance(int forAcctNum) {
        return findAccount(forAcctNum).getBalance();
    }

    public double withdraw(int forAcctNum, double amt) {
        return findAccount(forAcctNum).withdraw(amt);
    }

    public void login(String custname, String withPwd) throws CustNotFoundExn {
        Customer cust = this.findCustomer(custname);
        cust.checkPwd(withPwd);
    }
}
