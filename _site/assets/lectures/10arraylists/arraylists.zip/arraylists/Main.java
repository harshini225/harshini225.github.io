package arraylists;

import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        // this first section is the array demo, separate from lists
        String[] words = new String[5]; // 5 is the # of slots
        words[2] = "on";
        words[0] = "meet";
        System.out.println(Arrays.toString(words));
        System.out.println(words.length);

        // here's a shorthand for creating arrays
        String[] words2 = new String[] {"this", "creates", "an", "array"};
        System.out.println(Arrays.toString(words2));

        // this shows how our array list methods work
        ArrList arr = new ArrList(4);
        System.out.println(arr.toString());
        arr.addLast("long");
        arr.addLast("weekend");
        arr.addLast("is");
        System.out.println(arr.toString());
        arr.addLast("coming");
        System.out.println(arr.toString());
        arr.addLast("yay!");
        System.out.println(arr.toString());
        System.out.println(arr.get(2));
        // System.out.println(arr.get(5)); // will throw exception
    }
}
