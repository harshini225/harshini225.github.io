package lec13MVC;

import java.util.LinkedList;

public class Customer {
    String name;
    String password;
    LinkedList<Account> accounts = new LinkedList<Account>();

    public Customer(String nm, String pwd){
        this.name = nm;
        this.password = pwd;
    }

    public void addAccount(Account newAcct) {
        this.accounts.addFirst(newAcct);
    }

    public boolean nameMatches(String givenName) {
        return this.name.equals(givenName);
    }

    public void checkPwd(String givenPwd) throws WrongPwdException {
        if (! this.password.equals(givenPwd)) {
            throw new WrongPwdException(this.name);
        }
    }

    public boolean hasAccount(int acctNum) {
        for (Account acct:this.accounts) {
            if (acct.number == acctNum) {
                return true;
            }
        }
        return false;
    }
}
