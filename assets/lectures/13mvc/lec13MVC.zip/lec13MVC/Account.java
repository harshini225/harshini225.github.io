package lec13MVC;

public class Account {
    int number;
    Customer owner;
    double balance;

    Account(int num, Customer c, double bal){
        this.number = num;
        this.owner = c;
        this.balance = bal;
        this.owner.addAccount(this);
    }

    public void printBalance() {
        System.out.println("Account " + this.number + " balance: " + this.balance);
    }
}
