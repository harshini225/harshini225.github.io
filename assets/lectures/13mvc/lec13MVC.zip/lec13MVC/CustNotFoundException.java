package lec13MVC;

public class CustNotFoundException extends Exception {
    String name;

    public CustNotFoundException(String nm) {
        this.name = nm;
    }
}
