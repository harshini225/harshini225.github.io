package lec13MVC;

import java.util.LinkedList;
import java.util.Scanner;

public class BankingService {
    LinkedList<Account> accounts = new LinkedList<Account>();
    LinkedList<Customer> customers = new LinkedList<Customer>();

    public BankingService(){}

    public void addAccount(Account newA) {
        this.accounts.addFirst(newA);
    }

    public void addCust(Customer newC) { this.customers.addFirst(newC); }

    public double getBalance(int forAcctNum) {
        for (Account acct:accounts) {
            if (acct.number == forAcctNum)
                return acct.balance;
        }
        return 0;
    }

    public double withdraw(int forAcctNum, double amt) {
        for (Account acct:accounts) {
            if (acct.number == forAcctNum) {
                acct.balance = acct.balance - amt;
                return amt;
            }
        }
        return 0;
    }

    private Customer findCustomer(String custname)
            throws CustNotFoundException {
        for (Customer cust:customers) {
            if (cust.nameMatches(custname)) {
                return cust;
            }
        }
        throw new CustNotFoundException(custname);
    }

    public void login(String custname, String pwd)
            throws CustNotFoundException, WrongPwdException {
        Customer cust = findCustomer(custname);
        cust.checkPwd(pwd);
    }
}
