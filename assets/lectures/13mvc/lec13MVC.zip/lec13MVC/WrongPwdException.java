package lec13MVC;

public class WrongPwdException extends Exception {
    String username;
    public WrongPwdException(String nm) {
        this.username = nm;
    }
}
