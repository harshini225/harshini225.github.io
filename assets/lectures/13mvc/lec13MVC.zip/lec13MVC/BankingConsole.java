package lec13MVC;

import java.util.Scanner;

public class BankingConsole {
    BankingService B;

    public BankingConsole(BankingService B) {
        this.B = B;
    }

    public void loginScreen() {
        // Set up an object that reads text from the keyboard
        // (you will learn about this in I/O lab)
        Scanner keyboard = new Scanner(System.in);
        System.out.println("Welcome to the Bank! Please log in.");
        System.out.println("Enter username: ");
        String username = keyboard.next();
        System.out.println("Enter password: ");
        String password = keyboard.next();
        try {
            this.B.login(username, password);
        } catch (CustNotFoundException e) {
            System.out.println("Username " + e.name + " not found. Try again.");
            this.loginScreen();
        } catch (WrongPwdException e) {
            System.out.println("Unrecognized password for user " + e.username + ". Try again.");
            this.loginScreen();
        }
        System.out.println("Thanks for logging in!");
    }

}
