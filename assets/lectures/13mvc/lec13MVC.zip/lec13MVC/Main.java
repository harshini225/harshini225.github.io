package lec13MVC;

public class Main {
    public static void main(String[] args) {
        BankingService B = new BankingService();
        BankingConsole C = new BankingConsole(B);

        Customer kCust = new Customer("kathi", "cs200");
        Account kAcct = new Account(10065, kCust, 150);
        B.addCust(kCust);
        B.addAccount(kAcct);

        C.loginScreen();

        /*
        Note: you would create methods in BankingConsole for these actions so that they could be
        done and handled through the user interface. The BankingService would have a way of authenticating
        these actions to only allow withdrawals, balance printing for the logged in user.
         */
        kAcct.printBalance();
        B.withdraw(10065, 30);
        kAcct.printBalance();
    }
}
