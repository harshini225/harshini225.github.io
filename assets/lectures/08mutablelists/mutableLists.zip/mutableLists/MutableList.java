package mutableLists;

public class MutableList implements IList {
    Node start; // front of the list
    Node end;   // last node in the list

    public MutableList() {
        this.start = null;
        this.end = null;
    }

    public boolean isEmpty() {
        return (this.start == null);
    }

    public IList addFirst(int newItem) {
        Node newNode = new Node(newItem, this.start);
        // next line redirects start to the new node
        this.start = newNode;
        return this;
    }

    public IList addLast(int newItem) {
        Node newNode = new Node(newItem, null);
        // Each of next two lines sets up one arrow in the figure
        this.end.next = newNode;
        this.end = newNode;
    }

    public int size() {
        if (this.isEmpty()) {
            return 0;
        } else {
            return this.start.size();
        }
    }
}
