package mutableLists;

public class Node {
    int first;
    Node next;

    public Node(int first, Node next) {
        this.first = first;
        this.next = next;
    }

    public int size() {
        if (this.next == null) {
            return 1;
        } else {
            return 1 + this.next.size();
        }
    }
}
