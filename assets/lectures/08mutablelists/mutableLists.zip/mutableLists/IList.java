package mutableLists;

public interface IList {
    public boolean isEmpty();
    public IList addFirst(int newItem);
    public IList addLast(int newItem);
    public int size();
}
