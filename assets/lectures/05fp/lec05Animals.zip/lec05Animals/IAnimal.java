package lec05Animals;

public interface IAnimal {
    // determine whether animal is of normal size for its type
    public boolean isNormalSize();
}
