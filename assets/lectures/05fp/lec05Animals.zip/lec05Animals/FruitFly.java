package lec05Animals;

public class FruitFly implements IAnimal {
    public FruitFly() {}

    @Override
    public boolean isNormalSize() {
        return true;
    }
}
