package sol;

import src.LabStack;
import src.IStack;
import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class LabStackTest {
    private IStack testStack;

    private void makeTestStack() {
        this.testStack = new LabStack();
        // change to LabStackFixed() for example solution
    }

    private void pushValuesToStack() {
        this.testStack.push(1);
        this.testStack.push(2);
        this.testStack.push(3);
    }

    @Test
    public void testLabStackConstructor() {
        this.makeTestStack();
        Assert.assertEquals(0, this.testStack.size());
    }

    @Test
    public void testClear() {
        this.makeTestStack();
        this.pushValuesToStack();
        this.testStack.pop();
        Assert.assertNotEquals(0, this.testStack.size());
        this.testStack.clear();
        Assert.assertEquals(0, this.testStack.size());
    }

    @Test
    public void testPopSize() {
        this.makeTestStack();
        this.pushValuesToStack();
        int prePopSize = this.testStack.size();
        this.testStack.pop();
        Assert.assertEquals(prePopSize - 1, this.testStack.size());
    }

    @Test
    public void testPopVal() {
        this.makeTestStack();
        this.pushValuesToStack();
        this.testStack.push(200);
        this.testStack.push(2000);
        int popVal = this.testStack.pop();
        Assert.assertEquals(2000, popVal);
        popVal = this.testStack.pop();
        Assert.assertEquals(200, popVal);
    }

    @Test
    public void testPeekSize() {
        this.makeTestStack();
        this.pushValuesToStack();
        int prePeekSize = this.testStack.size();
        this.testStack.peek();
        Assert.assertEquals(prePeekSize, this.testStack.size());
    }

    @Test
    public void testPushPushPop() {
        this.makeTestStack();
        this.pushValuesToStack();
        this.testStack.push(4);
        this.testStack.push(6);
        this.testStack.pop();
        int peekVal = this.testStack.peek();
        Assert.assertEquals(4, peekVal);
    }

    @Test(expected = IllegalStateException.class)
    public void testPopEmpty() {
        this.makeTestStack();
        this.testStack.pop();
    }

    @Test(expected = IllegalStateException.class)
    public void testPeekEmpty() {
        this.makeTestStack();
        this.testStack.peek();
    }

    @Test
    public void testPushSize() {
        this.makeTestStack();
        this.pushValuesToStack();
        int prePushSize = this.testStack.size();
        this.testStack.push(5);
        Assert.assertEquals(prePushSize + 1, this.testStack.size());
    }

    @Test
    public void testPushEmpty() {
        this.makeTestStack();
        this.testStack.push(5);
        Assert.assertEquals(1, this.testStack.size());
    }
}
