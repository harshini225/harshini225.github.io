package sol;

import src.LabStackNode;
import src.IStack;

public class LabStackFixed implements IStack {
    private LabStackNode topNode;
    private int size;

    public LabStackFixed() {
        this.topNode = null;
        this.size = 0;
    }

    public int pop() {
        if (this.topNode == null) {
            throw new IllegalStateException();
        }
        int rVal = this.topNode.getValue();
        this.topNode = this.topNode.getNext();
        this.size--;
        return rVal;
    }

    public int peek() {
        if (this.topNode == null) {
            throw new IllegalStateException();
        }
        return this.topNode.getValue();
    }

    public void push(int i) {
        this.topNode = new LabStackNode(i, this.topNode);
        this.size++;
    }

    public void clear() {
        this.topNode = null;
        this.size = 0;
    }

    public int size() {
        return this.size;
    }
}
