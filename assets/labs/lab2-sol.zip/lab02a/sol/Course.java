package sol;

public class Course {
    String nameNum;
    private Faculty taughtBy;

    public Course(String nameNum, Faculty prof) {
        this.nameNum = nameNum;
        this.taughtBy = prof;
    }

    public void changeProf(Faculty newProf) {
        this.taughtBy = newProf;
    }

    public boolean isTaughtBy(Faculty f) {
        return this.taughtBy.equals(f);
    }

    public String profName() {
        return this.taughtBy.toString();
    }

    public Course clone() {
        return new Course(this.nameNum, this.taughtBy);
    }

    @Override
    public boolean equals(Object other) {
        if (other instanceof Course) {
            return this.nameNum.equals(((Course) other).nameNum);
        } else {
            return false;
        }
    }
}
