package sol;
import java.util.LinkedList;

public class Student extends Person {
    LinkedList<Course> taking;
    LinkedList<Course> completed;

    public Student(String name) {
        super(name);
        this.taking = new LinkedList<Course>();
        this.completed = new LinkedList<Course>();
    }

    public void endSemester() {
        for (Course c : this.taking) {
            this.completed.add(c.clone());
        }
        this.taking = new LinkedList<Course>();
    }

    public boolean hasCourseFrom(Faculty f) {
        for (Course c : this.taking) {
            if (c.isTaughtBy(f)) { // the corrected code
            //if (c.taughtBy.equals(f)) { // the old code
                return true;
            }
        }
        return false;
    }

    public LinkedList<String> tookCoursesFrom() {
        LinkedList<String> result = new LinkedList<String>();
        for (Course c : this.completed) {
            result.add(c.profName()); // the corrected code
            // result.add(c.taughtBy.name); // the old code
        }
        return result;
    }
}

