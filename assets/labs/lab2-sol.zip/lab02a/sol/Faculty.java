package sol;

public class Faculty extends Person {
    public Faculty(String name) {
        super(name);
    }
}
