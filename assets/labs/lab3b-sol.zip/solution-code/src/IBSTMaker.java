package src;

import sol.IBST;

import java.util.List;

public interface IBSTMaker {
    public IBST makeBST(List<Integer> list);
}
